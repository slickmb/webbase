less.strictMaths = false;
less.strictUnits = false;

describe("less.js legacy tests", function() {
    testLessEqualsInDocument();
});