less.relativeUrls = true;
describe("less.js browser test - relative url's", function() {
    testLessEqualsInDocument();
});